﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using WDI.BuisnessLogic;

namespace WDI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WDIController : ControllerBase
    {

        private IBuisnessLogic _BuisnessLogic;

        public WDIController(IBuisnessLogic buisnessLogic)
        {
            _BuisnessLogic = buisnessLogic;
        }
        [HttpPost("UploadMultipleFile")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status415UnsupportedMediaType)]
        [MultipartFormData]
        // [DisableRequestSizeLimit]
        [DisableFormValueModelBinding]
        //[RequestFormLimits(ValueLengthLimit = int.MaxValue, MultipartBodyLengthLimit = int.MaxValue)]
        public async Task<IActionResult> UploadFile(Guid fileID, string fileName)
        {
            try
            {

                return Ok(await _BuisnessLogic.UploadFile(HttpContext.Request.Body, fileID, Request.ContentType, fileName));
            }
            catch (Exception)
            {
                return BadRequest(Constants.WentWrong);
            }
        }

        [Route("UploadChunk")]
        [HttpPost]
        public async Task<IActionResult> UploadChunk([FromForm] UploadFile uploadFile)
        {
            try
            {
                if (uploadFile.File != null && uploadFile.File.Length > 0 && (uploadFile.DirectUpload == true ? !string.IsNullOrEmpty(uploadFile.FolderID) : 1==1))
                    return Ok(_BuisnessLogic.UploadChunk(uploadFile));

                return BadRequest(Constants.FillAllRequiredFields);

            }
            catch (Exception)
            {
                return BadRequest(Constants.WentWrong);
            }
        }

        [Route("MergeFile")]
        [HttpPost]
        public async Task<IActionResult> MergeFile(MergeFile mergeFile)
        {
            try
            {
                if(!string.IsNullOrEmpty(mergeFile.FolderID) && !string.IsNullOrEmpty(mergeFile.FileName))
                {
                    return Ok(_BuisnessLogic.MergeFile(mergeFile));
                }
                return BadRequest();

            }
            catch (Exception)
            {
                return BadRequest(Constants.WentWrong);
            }
        }

        [Route("Download")]
        [HttpGet]
        public async Task<IActionResult> DownloadFile(Guid fileID)
        {
            try
            {
                if (fileID != null)
                {
                    var downloadFileDetails = _BuisnessLogic.DownloadFile(fileID);

                    if (downloadFileDetails._isSucceed == true && downloadFileDetails._data.GetType().GetProperty("FileContent") != null)
                    {
                        byte[] filebytes = ((DownloadFile)downloadFileDetails._data).FileContent;

                        return File(filebytes, System.Net.Mime.MediaTypeNames.Application.Octet, $"{((DownloadFile)downloadFileDetails._data).FileName}");
                    }
                    else
                    {
                        return Ok(downloadFileDetails);
                    }
                }

                return BadRequest();

            }
            catch (Exception)
            {
                return BadRequest(Constants.WentWrong);
            }
        }
    }
}
