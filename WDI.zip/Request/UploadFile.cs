﻿namespace WDI
{
    public class UploadFile
    {
        public string? FolderID { get; set; }
        public bool DirectUpload { get; set; }
        public IFormFile File { get; set; }
    }

    public class MergeFile
    {
        public string FolderID { get; set; }
        public Guid FileID { get; set; }
        public string FileName { get; set; }
    }
}
