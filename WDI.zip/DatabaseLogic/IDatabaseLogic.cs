﻿namespace WDI
{
    public interface IDatabaseLogic
    {

        bool InsertFiles(Guid fileID,string fileName,string filePath, byte[] fileContent);

        DownloadFile? DownloadFile(Guid fileID);
    }
}
