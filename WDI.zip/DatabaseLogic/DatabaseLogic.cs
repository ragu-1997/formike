﻿

namespace WDI
{
    public class DatabaseLogic : IDatabaseLogic
    {

        public bool InsertFiles(Guid fileID, string fileName, string filePath, byte[] fileContent)
        {
            try
            {
                using (WdiContext dbContext = new WdiContext())
                {
                    File file = new File
                    {
                        FileId = fileID,
                        FileName = fileName,
                        FilePath = filePath,
                        FileContent = fileContent,
                        FileSize = fileContent.Length

                    };

                    dbContext.Files.Add(file);
                    dbContext.SaveChanges();

                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DownloadFile? DownloadFile(Guid fileID)
        {
            DownloadFile? downloadFileResponse = new DownloadFile();
            try
            {
                using (WdiContext dbContext = new WdiContext())
                {

                   return downloadFileResponse = dbContext.Files.Where(x => x.FileId == fileID).Select(x => new DownloadFile
                    {
                        FileContent=x.FileContent,
                        FileName=x.FileName
                    }).FirstOrDefault();
                    
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
