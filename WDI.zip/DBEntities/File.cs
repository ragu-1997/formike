﻿using System;
using System.Collections.Generic;

namespace WDI;

public partial class File
{
    public int Id { get; set; }

    public Guid FileId { get; set; }

    public string FileName { get; set; } = null!;

    public string FilePath { get; set; } = null!;

    public long? FileSize { get; set; }

    public byte[]? FileContent { get; set; }
}
