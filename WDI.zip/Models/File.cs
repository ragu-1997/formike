﻿using System;
using System.Collections.Generic;

namespace WDI.Models;

public partial class File
{
    public long Id { get; set; }

    public Guid FileId { get; set; }

    public string FileName { get; set; } = null!;

    public string FilePath { get; set; } = null!;

    public byte[]? FileContent { get; set; }

    public long? FileSize { get; set; }
}
