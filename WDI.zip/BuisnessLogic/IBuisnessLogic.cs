﻿
namespace WDI.BuisnessLogic
{
    public interface IBuisnessLogic
    {
        Task<ResponseObject> UploadFile(Stream filestream,  Guid fileid, string contentType, string fileName);

        ResponseObject UploadChunk(UploadFile uploadFile);
        ResponseObject MergeFile(MergeFile uploadFile);
        ResponseObject DownloadFile(Guid fileID);
    }
}
