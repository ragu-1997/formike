﻿using Microsoft.AspNetCore.WebUtilities;
using System.Diagnostics;
using Microsoft.Net.Http.Headers;
using System.Collections;
using Microsoft.AspNetCore.Mvc.Routing;
using System.IO;

namespace WDI.BuisnessLogic
{
    public class BuisnessLogic : IBuisnessLogic
    {
        private IDatabaseLogic _databaseLogic;
        private ResponseObject responseObject;

        public BuisnessLogic(IDatabaseLogic databaseLogic)
        {
            _databaseLogic = databaseLogic;
        }
        public async Task<ResponseObject> UploadFile(Stream fileStream, Guid fileid, string contentType, string fileName)
        {
            try
            {
                var boundary = GetBoundary(MediaTypeHeaderValue.Parse(contentType));
                var multipartReader = new MultipartReader(boundary, fileStream);
                var section = await multipartReader.ReadNextSectionAsync();

                FileStream fs = fileStream as FileStream;

                if (fs != null)
                {
                    string destinationDirectoryName = $"/opt/vault/Files/{Path.GetFileNameWithoutExtension(fileName)}/{fileid}/";

                    if (!Directory.Exists(destinationDirectoryName))
                        Directory.CreateDirectory(destinationDirectoryName);

                    destinationDirectoryName = Path.Combine(destinationDirectoryName);

                    #region Commented
                    //using (MemoryStream outputStream = new MemoryStream())
                    //{
                    //    while (section != null)
                    //    {
                    //        FileMultipartSection? fileSection = section.AsFileSection();
                    //        if (fileSection != null)
                    //        {
                    //            fileSection.FileStream?.CopyTo(outputStream);
                    //            fileCount++;
                    //        }
                    //        section = await multipartReader.ReadNextSectionAsync();
                    //    }

                    //    afterUpload.Stop();

                    //    uploadMultipleFileTimeTaken += $" File Stream write Process Elapsed Milliseconds - {afterUpload.ElapsedMilliseconds}, Elapsed Seconds - {afterUpload.Elapsed.TotalSeconds}" + Environment.NewLine;

                    //    if (outputStream.Length > 0)
                    //    {

                    //        Stopwatch vaultUpload = Stopwatch.StartNew();

                    //        byte[] byteContent = outputStream.ToArray();

                    //        if (byteContent.Length > 0)
                    //            File.WriteAllBytes(destinationDirectoryName, byteContent);


                    //        //using (var vaultUploadStream = new FileStream(destinationDirectoryName, FileMode.Create, FileAccess.Write))
                    //        //{
                    //        //    outputStream.CopyTo(vaultUploadStream);
                    //        //}
                    //        vaultUpload.Stop();

                    //        uploadMultipleFileTimeTaken += $" Vault Upload Process Elapsed Milliseconds - {vaultUpload.ElapsedMilliseconds}, Elapsed Seconds - {vaultUpload.Elapsed.TotalSeconds}, ByteContent Length - {byteContent.Length}" + Environment.NewLine;
                    //        uploadSucceed = true;
                    //        //iFCImport_BLHelper = new IFCImport_BLHelper();

                    //        //string folderPath = await iFCImport_BLHelper.SendMultiple(ms, site, fileName, version);


                    //    }


                    //    //}

                    //    //using (var outputStream = File.Create(Path.Combine(outputpath, fileName)))
                    //    //{
                    //    //    while (section != null)
                    //    //    {
                    //    //        FileMultipartSection? fileSection = section.AsFileSection();
                    //    //        if (fileSection != null)
                    //    //        {
                    //    //            //  totalSizeInBytes += await SaveFileAsync(fileSection, filePaths, notUploadedFiles);

                    //    //            // Buffer size can be passed as the second argument.
                    //    //            fileSection.FileStream?.CopyTo(outputStream);
                    //    //            fileCount++;
                    //    //        }
                    //    //        section = await multipartReader.ReadNextSectionAsync();

                    //    //    }
                    //    //}

                    //    //iFCImport_BLHelper = new IFCImport_BLHelper();

                    //    //bytedata = IFCImport_BLHelper.ReadFile(Path.Combine(outputpath, fileName));

                    //    //if (bytedata.Length > 0)
                    //    // {
                    //    //string folderPath = await iFCImport_BLHelper.SendMultiple(new MemoryStream(bytedata), site, fileName, version);

                    //    //if (!string.IsNullOrEmpty(folderPath))
                    //    //{

                    //    //    bool response = _iFC_IDatabaseLogic.UpdateRVTFilePath(0, folderPath, pdmfileID);

                    //    //    responseObject = (response) ? new ResponseObject(false, new ArrayList(), RequestConstants.REVITIMPORTED) : new ResponseObject(false, new ArrayList(), RequestConstants.IfcImportFailed);
                    //    //}
                    //    //}
                    //    //else
                    //    //{
                    //    //    responseObject = new ResponseObject(false, new ArrayList(), RequestConstants.IfcImportFailed);
                    //    //}
                    //}

                    //if (!string.IsNullOrEmpty(destinationDirectoryName) && uploadSucceed == true)
                    //{
                    //    iFCImport_BLHelper = new IFCImport_BLHelper();

                    //    // bool response = _iFC_IDatabaseLogic.UpdateRVTFilePath(0, destinationDirectoryName, pdmfileID);

                    //    responseObject = (true) ? new ResponseObject(false, new ArrayList(), RequestConstants.REVITIMPORTED) : new ResponseObject(false, new ArrayList(), RequestConstants.IfcImportFailed);
                    //}
                    //else
                    //{
                    //    responseObject = new ResponseObject(false, new ArrayList(), RequestConstants.IfcImportFailed);
                    //}

                    #endregion

                    #region Direct Upload Stream
                    using (var outputStream = new FileStream(destinationDirectoryName, FileMode.Create, FileAccess.Write))
                    {
                        while (section != null)
                        {
                            FileMultipartSection? fileSection = section.AsFileSection();

                            if (fileSection != null)
                            {
                                fileSection.FileStream?.CopyTo(outputStream);
                            }

                            section = await multipartReader.ReadNextSectionAsync();
                        }

                    }

                    byte[] fileBytes = System.IO.File.ReadAllBytes(destinationDirectoryName);

                    bool success = _databaseLogic.InsertFiles(fileid, fileName, destinationDirectoryName, fileBytes);

                    responseObject = success == true ? new ResponseObject(true, new ArrayList(), Constants.FileImported) : new ResponseObject(true, new ArrayList(), Constants.FileImportFailed);

                    #endregion
                }
            }
            catch (Exception)
            {
                responseObject = new ResponseObject(false, new ArrayList(), Constants.WentWrong);
                // throw;
            }
            return responseObject;
        }

        private string GetBoundary(MediaTypeHeaderValue contentType)
        {

            var boundary = HeaderUtilities.RemoveQuotes(contentType.Boundary).Value;

            if (string.IsNullOrWhiteSpace(boundary))
            {
                throw new InvalidDataException("Missing content-type boundary.");
            }

            return boundary;
        }

        public ResponseObject UploadChunk(UploadFile uploadFile)
        {
            BLHelper blHelper = new BLHelper();
            try
            {
                ArrayList arrayList = new ArrayList();

                if (uploadFile.File != null && uploadFile.File.Length > 0)
                {
                    if (uploadFile.DirectUpload == false)
                    {
                        using (var ms = new MemoryStream())
                        {
                            uploadFile.File.CopyTo(ms);
                            var fileBytes = ms.ToArray();
                            var stream = new MemoryStream(fileBytes);

                            var ext = Path.GetExtension(uploadFile.File.FileName).Replace(".", "").ToLower();


                            string folderID = blHelper.UploadChunk(fileBytes, Path.GetFileNameWithoutExtension(uploadFile.File.FileName), uploadFile.FolderID, ext);

                            if (!string.IsNullOrEmpty(folderID))
                            {
                                arrayList.Add(folderID);
                            }
                        }
                        responseObject = new ResponseObject(true, arrayList, Constants.FileImportInProcess);
                    }
                    else
                    {
                        string destinationDirectoryName = string.Empty;

                        using (var ms = new MemoryStream())
                        {
                            uploadFile.File.CopyTo(ms);
                            var fileBytes = ms.ToArray();
                            MemoryStream stream = new MemoryStream(fileBytes);

                            destinationDirectoryName = blHelper.UploadVault(stream,/*uploadFile,*/uploadFile.File.FileName, uploadFile.FolderID);

                            bool success = _databaseLogic.InsertFiles(new Guid(uploadFile.FolderID), uploadFile.File.FileName, destinationDirectoryName, fileBytes);

                            responseObject = success == true ? new ResponseObject(true, new ArrayList(), Constants.FileImported) : new ResponseObject(true, new ArrayList(), Constants.FileImportFailed);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // throw;
                responseObject = new ResponseObject(false, new ArrayList(), Constants.WentWrong);
            }
            return responseObject;
        }
        

        public ResponseObject MergeFile(MergeFile mergeFile)
        {
            try
            {
                string outputpath = Path.Combine(Path.GetTempPath(), "Chunk", mergeFile.FolderID);

                string temppath = outputpath;

                DirectoryInfo dir = new DirectoryInfo(outputpath);
                List<FileInfo> inputFilePaths = dir.GetFiles().ToList();
                if (inputFilePaths.Count > 0)
                {
                    inputFilePaths = inputFilePaths.OrderBy(x => x.CreationTime).ToList();

                     outputpath = Path.Combine(outputpath, Guid.NewGuid().ToString());

                    if (!Directory.Exists(outputpath))
                        Directory.CreateDirectory(outputpath);

                    using (var outputStream = System.IO.File.Create(Path.Combine(outputpath, mergeFile.FileName)))
                    {
                        foreach (var inputFilePath in inputFilePaths)
                        {
                            using (var inputStream = System.IO.File.OpenRead(inputFilePath.FullName))
                            {
                                // Buffer size can be passed as the second argument.
                                inputStream.CopyTo(outputStream);
                            }
                        }
                    }
                    byte[] bytedata = ReadFile(Path.Combine(outputpath, mergeFile.FileName));

                    Directory.Delete(temppath,true);

                    BLHelper blHelper = new BLHelper();
                   string destinationDirectoryName = blHelper.UploadVault(new MemoryStream(bytedata),mergeFile.FileName, mergeFile.FolderID);

                    bool success = _databaseLogic.InsertFiles(mergeFile.FileID, mergeFile.FileName, destinationDirectoryName, bytedata);

                    responseObject = success == true ? new ResponseObject(true, new ArrayList(), Constants.FileImported) : new ResponseObject(true, new ArrayList(), Constants.FileImportFailed);
                }
            }
            catch (Exception ex)
            {
                responseObject = new ResponseObject(false, new ArrayList(), Constants.WentWrong);
                //throw;
            }
            return responseObject;
        }


        public ResponseObject DownloadFile(Guid fileID)
        {
            try
            {
                var downloadFile = _databaseLogic.DownloadFile(fileID);

                responseObject = (downloadFile != null && downloadFile.FileContent.Length > 0) ? new ResponseObject(true, downloadFile, Constants.DataRetrived) : new ResponseObject(true, new ArrayList(), Constants.NoDataFound);
            }
            catch (Exception)
            {

                throw;
            }
            return responseObject;
        }

        #region ReadFile
        public static byte[] ReadFile(string filePath)
        {
            byte[] buffer;
            FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            try
            {
                int length = (int)fileStream.Length;
                buffer = new byte[length];
                int count;
                int sum = 0;
                // read until Read method returns 0 (end of the stream has been reached)
                while ((count = fileStream.Read(buffer, sum, length - sum)) > 0)
                    sum += count;  // sum is a buffer offset for next reading
            }
            finally
            {
                fileStream.Close();
            }
            return buffer;
        }
        #endregion
    }
}
