﻿using Renci.SshNet;
using Renci.SshNet.Common;
using Renci.SshNet.Sftp;

namespace WDI.BuisnessLogic
{
    public class BLHelper
    {
        public string UploadChunk(byte[] bytes, string filename, string folderid, string fileextension)
        {
            string folderID = string.Empty;
            try
            {
                //string newGuid = Guid.NewGuid().ToString();

                string destinationDirectoryName = string.Empty;

                string path = Path.Combine(Path.GetTempPath(), "Chunk");

                if (!Directory.Exists(path))
                    Directory.CreateDirectory(path);

                if (string.IsNullOrEmpty(folderid))
                {
                    folderID = Guid.NewGuid().ToString();
                    destinationDirectoryName = Path.Combine(path, folderID);
                    if (!Directory.Exists(destinationDirectoryName))
                    {
                       Directory.CreateDirectory(destinationDirectoryName);
                    }
                }
                else
                {
                    destinationDirectoryName = Path.Combine(path, folderid);
                    folderID = folderid;
                }
                using (FileStream fs = new FileStream(Path.Combine(destinationDirectoryName, filename + "." + fileextension), FileMode.CreateNew, FileAccess.Write))
                {
                    fs.Write(bytes, 0, (int)bytes.Length);
                    fs.Close();

                }
            }

            catch (Exception)
            {
                throw;
            }
            return folderID;

        }
        public string UploadVault(MemoryStream fileStream,/*UploadFile uploadFile,*/string fileName,string fileID)
        {
            string destinationDirectoryName = $"/opt/vault/Files/{Path.GetFileNameWithoutExtension(fileName)}/{fileID}/";
            try
            {
                if (Constants.DirectVaultUpload == true)
                {

                    if (!Directory.Exists(destinationDirectoryName))
                        Directory.CreateDirectory(destinationDirectoryName);

                    destinationDirectoryName = Path.Combine(destinationDirectoryName, $"{fileName}");

                    using (var outputStream = new FileStream(destinationDirectoryName, FileMode.Create, FileAccess.Write))
                    {
                       // uploadFile.File.CopyTo(outputStream);
                        fileStream.CopyTo(outputStream);
                    }
                }
                else if (Constants.IsSSHKeyFileEnable)
                {
                    var binpath = AppDomain.CurrentDomain.BaseDirectory;
                    binpath = Path.Combine(binpath, "CloudBLM.ppk");

                    var privatekey = new PrivateKeyFile(binpath);

                    var keyFiles = new[] { privatekey };

                    using (var sftp = new SftpClient(Constants.SFTPHost, Constants.SFTPPort, Constants.SFTPUserName, keyFiles))
                    {
                        sftp.Connect();

                        if (!sftp.Exists(destinationDirectoryName))
                        {
                           // CreateDirectoryRecursively(sftp, destinationDirectoryName);
                            sftp.CreateDirectory(destinationDirectoryName);
                        }

                        destinationDirectoryName = Path.Combine(destinationDirectoryName, fileName);

                        sftp.UploadFile(fileStream, destinationDirectoryName, true);

                        sftp.Disconnect();
                    }
                }
                else
                {
                    using (var sftp = new SftpClient(Constants.SFTPHost, Constants.SFTPPort, Constants.SFTPUserName, Constants.SFTPPassword))
                    {
                        sftp.Connect();

                        if (!sftp.Exists(destinationDirectoryName))
                        {
                            // CreateDirectoryRecursively(sftp, destinationDirectoryName);
                            sftp.CreateDirectory(destinationDirectoryName);
                        }

                        destinationDirectoryName = Path.Combine(destinationDirectoryName, $"{fileName}");

                        sftp.UploadFile(fileStream, destinationDirectoryName, true);
                        sftp.Disconnect();
                    }
                }
              
            }
            catch (Exception)
            {

                throw;
            }
            return destinationDirectoryName;
        }

        private void CreateDirectoryRecursively(SftpClient client, string path)
        {
            try
            {
                string current = "";

                if (path[0] == '/')
                {
                    path = path.Substring(1);
                }

                while (!string.IsNullOrEmpty(path))
                {
                    int p = path.IndexOf('/');
                    current += '/';
                    if (p >= 0)
                    {
                        current += path.Substring(0, p);
                        path = path.Substring(p + 1);
                    }
                    else
                    {
                        current += path;
                        path = "";
                    }

                    try
                    {
                        SftpFileAttributes attrs = client.GetAttributes(current);
                        if (!attrs.IsDirectory)
                        {
                            throw new Exception("not directory");
                        }
                    }
                    catch (SftpPathNotFoundException)
                    {
                        client.CreateDirectory(current);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


    }
}
