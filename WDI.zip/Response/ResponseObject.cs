﻿namespace WDI
{
    public class ResponseObject
    {
        public bool _isSucceed { get; set; }
        public object _data { get; set; }
        public string _msg { get; set; }

        public ResponseObject()
        {
            this._isSucceed = false;
            this._data = null;
            this._msg = null;
        }

        public ResponseObject(bool _isSucceed, object _data, string _msg)
        {
            this._isSucceed = _isSucceed;
            this._data = _data;
            this._msg = _msg;
        }
    }
}
