﻿namespace WDI
{
    public class DownloadFile
    {
        public byte[] FileContent { get; set; }
        public string FileName { get; set; }
    }
}
