using WDI;
using WDI.BuisnessLogic;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


builder.Services.AddCors(o => o.AddPolicy("CloudBLM", builder =>
{
    builder.AllowAnyOrigin()
           .AllowAnyMethod()
           .AllowAnyHeader();
}));

builder.WebHost.UseUrls("http://0.0.0.0:5012");

builder.Services.AddTransient<IBuisnessLogic, BuisnessLogic>();
builder.Services.AddTransient<IDatabaseLogic, DatabaseLogic>();

Constants.SFTPHost = builder.Configuration.GetSection("SFTPHost").Value;
Constants.SFTPPort = Convert.ToInt16(builder.Configuration.GetSection("SFTPPort").Value);
Constants.SFTPUserName = builder.Configuration.GetSection("SFTPUserName").Value;
Constants.SFTPPassword = builder.Configuration.GetSection("SFTPPassword").Value;
Constants.ConnectionString = builder.Configuration.GetSection("ConnectionString").Value;
Constants.IsSSHKeyFileEnable = Convert.ToBoolean(builder.Configuration.GetSection("IsSSHKeyFileEnable").Value);
Constants.DirectVaultUpload = Convert.ToBoolean(builder.Configuration.GetSection("DirectVaultUpload").Value);

var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger();
app.UseSwaggerUI();
//}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
