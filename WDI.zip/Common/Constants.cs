﻿namespace WDI
{
    public class Constants
    {
        public const string FillAllRequiredFields = "Please fill all the required field details!";
        public const string FileImported = "File imported successfully";
        public const string FileImportFailed = "File Import Failed";
        public const string FileImportInProcess = "File Import in Process!";
        public const string WentWrong = "Something Went Wrong! Please Try again later!";
        public const string DataRetrived = " Data Retreived Successfully!";
        public const string NoDataFound = "No Records Found!";

        public static string SFTPHost { get; set; }
        public static short SFTPPort { get; set; }
        public static string SFTPUserName { get; set; }
        public static string SFTPPassword { get; set; }
        public static string ConnectionString { get; set; }
        public static bool DirectVaultUpload { get; set; }
        public static bool IsSSHKeyFileEnable { get; set; }
    }
}
